#ifndef STUDENTINFO_H
#define STUDENTINFO_H
#include<string>

//Insert your name is student id, letters and numbers only".
namespace StudentInfo {
	std::string Name() { return "Jason Irie"; }
	std::string ID() { return "1909713"; }
};

#endif